use eframe::egui;

fn main() -> Result<(), eframe::Error> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([400.0, 300.0])
            .with_title("Como usar botões"),
        ..Default::default()
    };

    eframe::run_native(
        "Como usar botões",
        options,
        Box::new(|_cc| {
            // Correção aqui: _cc.egui_ctx em vez de _cc.ego_ctx
            _cc.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::<MyApp>::default())
        }),
    )
}

#[derive(Default)]
struct MyApp {
    input_text: String,
    output_text: String,
}

impl eframe::App for MyApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Botões e Input Box");
            ui.add_space(10.0);

            ui.label("Introduza o texto aqui:");
            ui.add(
                egui::TextEdit::singleline(&mut self.input_text)
                    .hint_text("Introduza o texto aqui"),
            );
            ui.add_space(15.0);

            ui.horizontal(|ui| {
                if ui.button("💾 Guardar").clicked() {
                    self.output_text = self.input_text.clone();
                }

                ui.spacing_mut().item_spacing.x = 10.0;

                if ui.button("🗑 Apagar").clicked() {
                    self.input_text.clear();
                    self.output_text.clear();
                }
            });

            ui.add_space(20.0);

            if !self.output_text.is_empty() {
                ui.label(&self.output_text);
            }
        });
    }
}