use eframe::egui;

fn main() -> Result<(), eframe::Error> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([400.0, 300.0])
            .with_title("Olá mundo"),
        ..Default::default()
    };

    eframe::run_native(
        "Olá",
        options,
        Box::new(|cc| {
            cc.egui_ctx.set_visuals(egui::Visuals::dark());
            Ok(Box::new(MyApp::default()))
        }),
    )
}

#[derive(Default)]
struct MyApp {}

impl eframe::App for MyApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("Exemplo de Hello world");
            ui.add_space(10.0);

            ui.label("Aqui é para aparecer a frase");
            ui.add_space(20.0);

            // Adiciona o botão OK
            if ui.button("OK").clicked() {
                // Envia o comando para fechar a janela
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
        });
    }
}